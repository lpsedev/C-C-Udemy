#include <stdio.h>
#include <stdlib.h>
#include "functions.h"

int main(){

    //Chama a fun��o
    imprimeOi();

    //Retorno da Fun��o
    return 0;
}

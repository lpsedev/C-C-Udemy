void imprimeOi(){
    printf("Oi\n");
}

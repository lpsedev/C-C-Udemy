#include <stdio.h>
#include <stdlib.h>

//Fun��o que desenha borda
void desenhaBorda(){
     printf("|----| \n");
}


int main(){

    //Chamando a Fun��o
    desenhaBorda();

    //Imprimindo texto na tela
    printf("hi\n");

    //Chamando a Fun��o
    desenhaBorda();

    return 0;
}
